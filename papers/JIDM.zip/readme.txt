1. Movie Ratings (ratings.csv): [userid; itemid; rating]

2. Friendship relation  (friendship.csv):  [userid;friendship]

The friendship links are undirected. 

3. To use this data set in your research, please consider to cite our work: 

Crícia Z. Felício, Klérisson V. R. Paixão, Guilherme Alves, Sandra de Amo and Philippe Preux. Exploiting Social Information in Pairwise Preference Recommender System. In Journal of Information and Data Management (JIDM), pages 99-115, 2016.

@article{felicioJIDM,
   author    = {Fel{\'i}cio, Cr{\'i}cia Z. and Paix{\~a}o, Kl{\'e}risson V. R. and Alves, Guilherme and de Amo, Sandra and Preux, Philippe},
  title     = {Exploiting social information in pairwise preference recommender system},
  journal   = {Journal of Information and Data Management (JIDM)},
  year      = {2016},
  volume	= {7},
  number	= {2},
  pages 	= {99--115} 
}
