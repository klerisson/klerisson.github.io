if(!require(fmsb)){install.packages("fmsb")}

########### RQ1

### Cloudify
data <- matrix(c(3882,823,399,72,34,23), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                         Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Failed
significant <- matrix(c(3882,823,72,34), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

# Passed - Errored
significant <- matrix(c(3882,399,72,23), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

### Gradle
data <- matrix(c(2872,191,98,477,29,18), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                          Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

###SONAR
data <- matrix(c(2349,399,193,348,67,55), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                        Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Errored
significant <- matrix(c(2349,193,348,55), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

# Failed - Errored
significant <- matrix(c(399,193,348,55), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

###Orbeon
data<- matrix(c(1135,982,296,24,24,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                       Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

###Geoserver
data<- matrix(c(1032,930,144,117,104,19), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### GrayLog
data<- matrix(c(1840,56,71,208,6,20), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Errored
significant <- matrix(c(1840,71,208,20), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

### okhttp
data<- matrix(c(949,271,382,192,107,111), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Failed
significant <- matrix(c(949,271,192,107), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

# Passed - Errored
significant <- matrix(c(949,382,192,111), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

### LanguageTool
data<- matrix(c(1646,151,21,34,5,1), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Lorsource
data<- matrix(c(1551,58,62,87,4,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Traccar
data<- matrix(c(1590,28,15,107,1,4), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# no significance

### DSpace
data<- matrix(c(1528,55,28,43,4,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### jooq
data<- matrix(c(1000,84,396,112,4,43), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("No", "Yes"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

################## RQ2 ##################
### Rename Method against others  
data <- matrix(c(2319,470,354,649,152,111), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Move Attribute	
data <- matrix(c(2736,578,437,232,44,28), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Extract Method	
data <- matrix(c(2394,469,359,574,153,106), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Failed
significant <- matrix(c(2394,469,574,153), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

### Move Method	
data <- matrix(c(2738,577,427,230,45,38), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Move Class	
data <- matrix(c(2729,591,427,239,31,38), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

# Passed - Failed
significant <- matrix(c(2729,591,239,31), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")


### Pull Up Method	
data <- matrix(c(2864,602,454,104,20,11), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance


### Rename Class	
data <- matrix(c(2648,574,422,320,48,43), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#almost

### Push Down Method	
data <- matrix(c(36,6,0,2932,616,465), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
# Discarded due 0 errors

### Extract And Move Method	
data <- matrix(c(2882,605,446,86,17,19), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

#Push Down Attribute  
data <- matrix(c(2929,614,462,39,8,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Extract Interface	
data <- matrix(c(2921,616,460,47,6,5), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Move Source Folder	
data <- matrix(c(2894,608,445,74,14,20), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#almost

### Rename Package	
data <- matrix(c(2936,619,459,32,3,6), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Extract Superclass	
data <- matrix(c(2870,596,451,98,26,14), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Pull Up Attribute	
data <- matrix(c(2886,608,455,82,14,10), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Inline Method  
data <- matrix(c(2842,587,452,126,35,13), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Others","Refactored"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance


########### RQ3 ########################################################

### Rename Method 
data <- matrix(c(384,78,56,265,74,55), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Move Attribute  
data <- matrix(c(61,8,7,171,36,21), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Extract Method 
data <- matrix(c(402,99,65,172,54,41), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Move Method  
data <- matrix(c(70,5,12,160,40,26), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
# Passed - Failed
significant <- matrix(c(70,5,160,40), nrow = 2, ncol=2, byrow=TRUE)
fisher.test((significant),alternative = "two.sided")

### Move Class  
data <- matrix(c(118,12,19,121,19,19), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Pull Up Method  
data <- matrix(c(4,1,2,100,19,9), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Rename Class  
data <- matrix(c(162,16,18,158,32,25), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Pull Up Attribute  
data <- matrix(c(4,1,1,78,13,9), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Extract Superclass  
data <- matrix(c(7,2,4,91,24,10), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Inline Method  
data <- matrix(c(45,13,5,81,22,8), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = cc("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Push Down Method  
data <- matrix(c(0,1,0,36,5,0), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = cc("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Extract And Move Method  
data <- matrix(c(28,8,4,58,9,15), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Push Down Attribute  
data <- matrix(c(2,0,0,37,8,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Extract Interface 
data <- matrix(c(19,3,2,28,3,3), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance

### Move Source Folder   
data <- matrix(c(55,12,14,19,2,6), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")

#no significance

### Rename Package  
data <- matrix(c(8,1,1,24,2,5), nrow = 2, ncol=3, byrow=TRUE)
dimnames(data) = list(Refactoring = c("Single", "Multiple"),
                      Status = c("Passed", "Failed", "Errored"))
pairwise.fisher.test(t(data), p.adjust.method = "bonferroni", alternative = "two.sided")
#no significance