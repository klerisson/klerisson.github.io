library(arules);
library(arulesViz);

tdata <- read.transactions("/home/klerisson/Documents/PhD/research_artifacts/RefactoringAndBuilds/tr_refac.csv", 
                           sep=",", skip=1, format="single", cols = c(1,2))

passed <- read.transactions("/home/klerisson/Documents/PhD/research_artifacts/RefactoringAndBuilds/tr_refac_passed.csv", 
                           sep=",", skip=1, format="single", cols = c(1,2))

failed <- read.transactions("/home/klerisson/Documents/PhD/research_artifacts/RefactoringAndBuilds/tr_refac_failed.csv", 
                            sep=",", skip=1, format="single", cols = c(1,2))

errored <- read.transactions("/home/klerisson/Documents/PhD/research_artifacts/RefactoringAndBuilds/tr_refac_errored.csv", 
                            sep=",", skip=1, format="single", cols = c(1,2))


frequentItems <- eclat (tdata, parameter = list(supp = 0.02, maxlen = 10000)) # calculates support for frequent items
inspect(frequentItems)

frequentItems <- eclat (passed, parameter = list(supp = 0.02, maxlen = 10000)) # calculates support for frequent items
inspect(frequentItems)

frequentItems <- eclat (failed, parameter = list(supp = 0.02, maxlen = 10000)) # calculates support for frequent items
inspect(frequentItems)

frequentItems <- eclat (errored, parameter = list(supp = 0.02, maxlen = 10000)) # calculates support for frequent items
inspect(frequentItems)

